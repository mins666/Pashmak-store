# پشمک استور — Android Offline v1.0.10

این نسخه، صفحه وب را داخل خود برنامه بسته‌بندی می‌کند و برای اجرای برنامه به Cloudflare یا Chrome وابسته نیست.

- اجرای آفلاین
- ذخیره اطلاعات داخل WebView
- انتخاب فایل برای ورود موجودی اولیه
- رابط نسخه PWA v1.0.10
- بدون مجوز اینترنت در Manifest

برای ساخت APK، پروژه را در Android Studio یا AndroidIDE باز کنید و assembleDebug/assembleRelease را اجرا کنید.
